# Your Next Pet — Bot Discord + API

Ce projet contient un bot Discord et une petite API pour gérer les codes de récompense de la roue.

## Important avant de commencer

- Le ZIP ne contient PAS ton token Discord. Tu dois le créer dans le Discord Developer Portal et le coller uniquement dans les variables privées de Railway.
- Ne partage jamais `DISCORD_TOKEN` ni `SITE_API_SECRET`.
- Le site Netlify devra être modifié pour appeler l'API. Le bot ne peut pas modifier automatiquement ton ancien site.
- Ajoute un volume Railway monté sur `/data` pour conserver les codes après un redéploiement.

## Commandes Discord

- `/code-add recompense:<nom> code:<code>` : ajoute un code disponible.
- `/code-list` : liste les codes disponibles (visible uniquement par l'administrateur qui lance la commande).
- `/code-remove code:<code>` : retire un code disponible.

Les commandes sont réservées aux administrateurs du serveur.

## Déploiement Railway

1. Crée un dépôt GitHub et envoie-y le contenu de ce ZIP décompressé.
2. Dans Railway, crée un nouveau projet puis déploie le dépôt GitHub.
3. Dans **Variables**, ajoute les valeurs de `.env.example` :
   - `DISCORD_TOKEN` : token du bot, depuis Discord Developer Portal > Bot.
   - `DISCORD_CLIENT_ID` : Application ID, depuis General Information.
   - `DISCORD_GUILD_ID` : ID de ton serveur Discord (facultatif mais pratique pour tester).
   - `SITE_API_SECRET` : invente un long mot de passe secret.
   - `MASTER_CODE` : `X353m4Fl53xZ`.
   - `DATA_FILE` : `/data/codes.json`.
4. Ajoute un **Volume** Railway et règle son mount path sur `/data`.
5. Railway lance automatiquement `npm start`.
6. Une fois déployé, ouvre un terminal Railway et lance `npm run register` une seule fois pour publier les commandes Discord.
7. Dans Discord Developer Portal > OAuth2 > URL Generator, coche `bot` et `applications.commands`, puis invite le bot sur ton serveur. Donne-lui les permissions nécessaires pour voir les salons et utiliser les commandes.

## Relier le site Netlify

Le site doit envoyer une requête POST à `https://TON-DOMAINE-RAILWAY/api/spin` avec :
- l'en-tête `Content-Type: application/json`
- l'en-tête `x-api-secret: TON_SITE_API_SECRET`
- le corps JSON `{"masterCode":"X353m4Fl53xZ"}`

La réponse ressemble à :
`{"prize":"Œuf Astras","code":"EXEMPLE-CODE"}`

**Sécurité importante :** ne mets PAS `SITE_API_SECRET` dans le JavaScript public de Netlify : les visiteurs pourraient le lire. Pour une vraie mise en production, il faut faire l'appel depuis une fonction serveur Netlify (Netlify Function) qui garde le secret côté serveur. Ce ZIP fournit l'API et le bot, mais pas encore la fonction Netlify ni l'intégration exacte dans ton fichier HTML.

## Tester l'API

- `GET /health` doit répondre `{"ok":true}`.
- L'API de récompense est `POST /api/spin` et nécessite le secret privé.
