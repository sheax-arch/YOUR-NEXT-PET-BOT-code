const fs = require("node:fs");
const path = require("node:path");

const DATA_FILE = process.env.DATA_FILE || path.join(process.cwd(), "data", "codes.json");

function ensureFile() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ prizes: [], usedCodes: [] }, null, 2));
  }
}

function readData() {
  ensureFile();
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return { prizes: [], usedCodes: [] };
  }
}

function writeData(data) {
  ensureFile();
  const temp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(data, null, 2));
  fs.renameSync(temp, DATA_FILE);
}

module.exports = { readData, writeData };