require("dotenv").config?.();
const express = require("express");
const {
  Client, GatewayIntentBits, Events, MessageFlags
} = require("discord.js");
const { readData, writeData } = require("./store");

const required = ["DISCORD_TOKEN", "SITE_API_SECRET", "MASTER_CODE"];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Variable manquante : ${key}`);
    process.exit(1);
  }
}

const app = express();
app.use(express.json({ limit: "20kb" }));

app.get("/", (_req, res) => res.type("text").send("Your Next Pet API is online."));
app.get("/health", (_req, res) => res.json({ ok: true }));

function apiAuth(req, res, next) {
  const supplied = req.get("x-api-secret") || "";
  if (supplied.length !== process.env.SITE_API_SECRET.length ||
      !require("crypto").timingSafeEqual(Buffer.from(supplied), Buffer.from(process.env.SITE_API_SECRET))) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

// Called by the website after the wheel animation. One available code is claimed per spin.
app.post("/api/spin", apiAuth, (req, res) => {
  const enteredMasterCode = String(req.body?.masterCode || "");
  if (enteredMasterCode !== process.env.MASTER_CODE) {
    return res.status(403).json({ error: "Code d'accès incorrect." });
  }

  const data = readData();
  const available = data.prizes.filter(p => !p.used);
  if (!available.length) {
    return res.status(409).json({ error: "Aucun code de récompense disponible." });
  }

  const selected = available[Math.floor(Math.random() * available.length)];
  selected.used = true;
  selected.usedAt = new Date().toISOString();
  writeData(data);

  res.json({ prize: selected.prize, code: selected.code });
});

app.get("/api/status", apiAuth, (_req, res) => {
  const data = readData();
  res.json({
    available: data.prizes.filter(p => !p.used).length,
    total: data.prizes.length
  });
});

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, c => console.log(`Bot connecté : ${c.user.tag}`));

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  if (!interaction.memberPermissions?.has("Administrator")) {
    return interaction.reply({ content: "Réservé aux administrateurs.", flags: MessageFlags.Ephemeral });
  }

  const data = readData();

  if (interaction.commandName === "code-add") {
    const prize = interaction.options.getString("recompense", true).trim();
    const code = interaction.options.getString("code", true).trim();
    if (data.prizes.some(p => p.code.toLowerCase() === code.toLowerCase())) {
      return interaction.reply({ content: "Ce code existe déjà.", flags: MessageFlags.Ephemeral });
    }
    data.prizes.push({ id: require("crypto").randomUUID(), prize, code, used: false, createdAt: new Date().toISOString() });
    writeData(data);
    return interaction.reply({ content: `Code ajouté pour **${prize}**.`, flags: MessageFlags.Ephemeral });
  }

  if (interaction.commandName === "code-list") {
    const available = data.prizes.filter(p => !p.used);
    const summary = available.length
      ? available.map(p => `• **${p.prize}** — \`${p.code}\``).join("\n")
      : "Aucun code disponible.";
    return interaction.reply({ content: `**Codes disponibles (${available.length})**\n${summary}`.slice(0, 1900), flags: MessageFlags.Ephemeral });
  }

  if (interaction.commandName === "code-remove") {
    const code = interaction.options.getString("code", true).trim();
    const before = data.prizes.length;
    data.prizes = data.prizes.filter(p => p.code.toLowerCase() !== code.toLowerCase() || p.used);
    if (data.prizes.length === before) {
      return interaction.reply({ content: "Code introuvable ou déjà utilisé.", flags: MessageFlags.Ephemeral });
    }
    writeData(data);
    return interaction.reply({ content: "Code disponible supprimé.", flags: MessageFlags.Ephemeral });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`API démarrée sur le port ${port}`));
client.login(process.env.DISCORD_TOKEN);