require("dotenv").config?.();
const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

const commands = [
  new SlashCommandBuilder()
    .setName("code-add")
    .setDescription("Ajoute un code de récompense")
    .addStringOption(o => o.setName("recompense").setDescription("Nom du lot").setRequired(true))
    .addStringOption(o => o.setName("code").setDescription("Code à donner").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName("code-list")
    .setDescription("Affiche les codes encore disponibles")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName("code-remove")
    .setDescription("Supprime un code disponible")
    .addStringOption(o => o.setName("code").setDescription("Code à supprimer").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
].map(c => c.toJSON());

if (!process.env.DISCORD_TOKEN || !process.env.DISCORD_CLIENT_ID) {
  console.error("Il manque DISCORD_TOKEN ou DISCORD_CLIENT_ID dans les variables Railway.");
  process.exit(1);
}

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
(async () => {
  const route = process.env.DISCORD_GUILD_ID
    ? Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, process.env.DISCORD_GUILD_ID)
    : Routes.applicationCommands(process.env.DISCORD_CLIENT_ID);
  await rest.put(route, { body: commands });
  console.log("Commandes Discord enregistrées.");
})().catch(err => { console.error(err); process.exit(1); });